import functions
import random


def main():
    questions = functions.load_quetions()
    random.shuffle(questions)
    total_right_answer = 0
    total_score = 0
    print(f"Игра начинается!")
    for question in questions:

        print(question.build_question())
        answer = input()
        question.user_answer = answer
        question.is_question = True

        if question.is_correct():
            print(f"Ответ верный, получено {question.get_points()} баллов")
            total_right_answer += 1
            total_score += question.get_points()
        else:
            print(f"Ответ неверный, верный ответ: {question.right_answer}")
    print()
    print(f"Вот и всё!\
        \nОтвечено верно на {total_right_answer} вопроса из {len(questions)}\
        \nНабрано баллов: {total_score}")


main()
